﻿class Rectangle
{
    private int length;
    private int width;

    public int GetLength()
    {
        return length;
    }

    public int GetWidth()
    {
        return width;
    }
}
